library(testthat)
library(polygon)

test_check("polygon")
