#' @keywords internal
#' @aliases polygon-package
#utils::globalVariables(c("out", "font_family", "title_family"))
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @importFrom magrittr %>%
## usethis namespace: end
NULL
